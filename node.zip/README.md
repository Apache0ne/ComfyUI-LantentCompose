# LantentCompose using Slerp
Interpolate sdxl latents using slerp with and without a mask. use with unsample nodes for best effects
![Screenshot 2025-03-29 025342](https://github.com/user-attachments/assets/63702e96-14a9-4c3a-8ca5-8b7e501d5641)\
## Add-on Nodes 
A custom unsampler node to output every latent after each step of unsampling
A muti compose lantent node
## Notes 
A lot of testing and tunning numbers is needed to understand the best cases for each output needed. 
## Dependencies
None
## Installation
ComfyUI-Manager (rec)\
Can be downloaded from ComfyUI-manager\
IF using Windows Port version\
ComfyUI\Custom_nodes 
```git clone https://github.com/Apache0ne/ComfyUI-LantentCompose.git```\
